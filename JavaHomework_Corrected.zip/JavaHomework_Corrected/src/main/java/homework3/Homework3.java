package homework3;
import java.util.Scanner;

public class Homework3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter N: ");
        int n = input.nextInt();

        if (n <= 0) {
            System.out.println("N must be greater than zero.");
            input.close();
            return;
        }

        int[] array = new int[n];
        int sum = 0;

        for (int i = 0; i < n; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            array[i] = input.nextInt();
        }

        int max = array[0];
        int min = array[0];

        for (int number : array) {
            sum += number;
            if (number > max) max = number;
            if (number < min) min = number;
        }

        double average = (double) sum / n;

        System.out.println("Max = " + max);
        System.out.println("Min = " + min);
        System.out.println("Sum = " + sum);
        System.out.println("Average = " + average);

        System.out.print("Array elements: ");
        for (int number : array) System.out.print(number + " ");
        System.out.println();

        input.close();
    }
}
