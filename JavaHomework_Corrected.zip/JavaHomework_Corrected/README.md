# Java Homework

## Homework Number Two
The six original exercises are in the `homework2` package:
- Homework2_1: Odd numbers from 1 to n
- Homework2_2: Prime numbers from 1 to n
- Homework2_3: Horizontal line of stars
- Homework2_4: Square of stars
- Homework2_5: Triangle of stars
- Homework2_6: Reverse triangle of stars

## Homework Number Three
`homework3/Homework3.java`: Reads N numbers, then prints max, min, sum, average, and the array again.

## Open in NetBeans
Extract the ZIP, then choose File > Open Project and select the folder containing `pom.xml`.
In Source Packages, open `homework2` or `homework3`. Right-click the Java file and choose Run File.
